import { Outlet, useNavigate } from "react-router-dom";
import api from "../api/axios";

const navItems = [
  { label: "Dashboard", icon: "📊", path: "/vpaa/dashboard" },
  { label: "Enrollment", icon: "📋", path: "/vpaa/enrollment" },
  { label: "Retention", icon: "📈", path: "/vpaa/retention" },
  { label: "Shiftee & Transferee", icon: "🔄", path: "/vpaa/shiftee-transferee" },
  { label: "Faculty Performance", icon: "👨‍🏫", path: "/vpaa/faculty-performance" },
  { label: "Achievements", icon: "🏆", path: "/vpaa/achievements" },
  { label: "Board Exam Results", icon: "📝", path: "/vpaa/board-exam" },
  { label: "Class Monitoring", icon: "📓", path: "/vpaa/class-monitoring" },
  { label: "Student Performance", icon: "🎓", path: "/vpaa/student-performance" },
  { label: "Academic Periods", icon: "🗓️", path: "/vpaa/academic-periods" },
  { label: "Backup & Recovery", icon: "💾", path: "/vpaa/backup" },
  { label: "User Management", icon: "👤", path: "/vpaa/users" },
  { label: "Employees", icon: "🧑‍💼", path: "/vpaa/employees" },
];

export default function VPAALayout() {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem("user"));
  const location = window.location.pathname;

  const handleLogout = async () => {
    await api.post("/logout");
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    navigate("/login");
  };

  return (
    <div className="flex min-h-screen bg-gray-100">
      <div className="w-64 min-h-screen bg-[#7b1113] flex flex-col">
        <div className="p-6 border-b border-[#5e0d0f]">
          <h1 className="text-white font-bold text-xl">APMS</h1>
          <p className="text-red-200 text-xs mt-1">City College of Tagaytay</p>
        </div>
        <div className="p-4 border-b border-[#5e0d0f]">
          <p className="text-white font-semibold text-sm">Academic Performance</p>
          <p className="text-red-300 text-xs">Monitoring System</p>
        </div>
        <nav className="flex-1 p-3 flex flex-col gap-1">
          {navItems.map((item) => (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className={`flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium transition w-full text-left
                ${location === item.path
                  ? "bg-white text-[#7b1113]"
                  : "text-red-100 hover:bg-[#5e0d0f]"
                }`}
            >
              <span>{item.icon}</span>
              {item.label}
            </button>
          ))}
        </nav>
        <div className="p-3 border-t border-[#5e0d0f]">
          <button
            onClick={() => navigate("/dean/change-password")}
            className="flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium text-red-100 hover:bg-[#5e0d0f] w-full text-left transition"
          >
            <span>🔒</span> Change Password 
            </button>
          <button
            onClick={handleLogout}
            className="flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium text-red-100 hover:bg-[#5e0d0f] w-full text-left transition"
          >
            <span>🚪</span> Logout
          </button>
        </div>
      </div>

      <div className="flex-1 flex flex-col">
        <div className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-6">
          <h2 className="text-lg font-semibold text-gray-800">VPAA Portal</h2>
          <div className="flex items-center gap-3">
            <div className="text-right">
              <p className="text-sm font-semibold text-gray-800">{user?.name}</p>
              <p className="text-xs text-gray-400">VPAA</p>
            </div>
            <div className="w-9 h-9 rounded-full bg-[#7b1113] flex items-center justify-center text-white font-bold text-sm">
              {user?.name?.charAt(0)}
            </div>
          </div>
        </div>
        <main className="flex-1 p-6 overflow-y-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
