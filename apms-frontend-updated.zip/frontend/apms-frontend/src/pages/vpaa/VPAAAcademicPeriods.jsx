import { useState, useEffect } from "react";
import api from "../../api/axios";

const emptyForm = {
  school_year: "",
  semester: "1st",
  start_date: "",
  end_date: "",
  is_active: false,
};

export default function VPAAAcademicPeriods() {
  const [periods, setPeriods] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [editId, setEditId] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [success, setSuccess] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const res = await api.get("/academic-periods");
      const sorted = [...res.data].sort((a, b) =>
        (b.school_year || "").localeCompare(a.school_year || "") ||
        (a.semester || "").localeCompare(b.semester || "")
      );
      setPeriods(sorted);
    } catch {
      setError("Failed to load academic periods.");
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setForm({ ...form, [name]: type === "checkbox" ? checked : value });
  };

  const handleEdit = (period) => {
    setEditId(period.id);
    setForm({
      school_year: period.school_year || "",
      semester: period.semester || "1st",
      start_date: period.start_date || "",
      end_date: period.end_date || "",
      is_active: !!period.is_active,
    });
    setSuccess("");
    setError("");
    window.scrollTo(0, 0);
  };

  const handleCancel = () => {
    setEditId(null);
    setForm(emptyForm);
    setError("");
  };

  const handleSubmit = async () => {
    setSaving(true);
    setSuccess("");
    setError("");
    try {
      if (!form.school_year.trim()) {
        setError("School year is required (e.g. 2026-2027).");
        setSaving(false);
        return;
      }

      const payload = { ...form, school_year: form.school_year.trim() };

      if (editId) {
        await api.put(`/academic-periods/${editId}`, payload);
        setSuccess("Academic period updated.");
      } else {
        await api.post("/academic-periods", payload);
        setSuccess("Academic period created.");
      }
      handleCancel();
      loadData();
    } catch (err) {
      setError(err?.response?.data?.message || "Failed to save academic period. Check the fields and try again.");
    } finally {
      setSaving(false);
    }
  };

  const handleSetActive = async (period) => {
    setError("");
    try {
      await api.put(`/academic-periods/${period.id}`, { is_active: true });
      loadData();
    } catch {
      setError("Failed to update active period.");
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Delete this academic period? This cannot be undone.")) return;
    setError("");
    try {
      await api.delete(`/academic-periods/${id}`);
      loadData();
    } catch {
      setError("Failed to delete — it may already be referenced by submitted data.");
    }
  };

  return (
    <div className="flex flex-col gap-6">
      <div className="bg-[#7b1113] rounded-2xl p-6 text-white">
        <h1 className="text-2xl font-bold">Academic Periods 🗓️</h1>
        <p className="text-red-200 text-sm mt-1">
          Manually add and manage school years and semesters. Mark one period "Active" so it's the default for new DH submissions.
        </p>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <h3 className="text-base font-semibold text-gray-800 mb-4">
          {editId ? "Edit Academic Period" : "Add Academic Period"}
        </h3>

        {success && <div className="bg-green-50 text-green-700 text-sm px-4 py-2 rounded-lg mb-4">{success}</div>}
        {error && <div className="bg-red-50 text-red-700 text-sm px-4 py-2 rounded-lg mb-4">{error}</div>}

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="text-sm font-medium text-gray-700">School Year</label>
            <input type="text" name="school_year" value={form.school_year} onChange={handleChange}
              placeholder="e.g. 2026-2027"
              className="mt-1 w-full border border-gray-300 rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#7b1113]" />
          </div>
          <div>
            <label className="text-sm font-medium text-gray-700">Semester</label>
            <select name="semester" value={form.semester} onChange={handleChange}
              className="mt-1 w-full border border-gray-300 rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#7b1113]">
              <option value="1st">1st Semester</option>
              <option value="2nd">2nd Semester</option>
              <option value="Summer">Summer</option>
            </select>
          </div>
          <div>
            <label className="text-sm font-medium text-gray-700">Start Date (optional)</label>
            <input type="date" name="start_date" value={form.start_date || ""} onChange={handleChange}
              className="mt-1 w-full border border-gray-300 rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#7b1113]" />
          </div>
          <div>
            <label className="text-sm font-medium text-gray-700">End Date (optional)</label>
            <input type="date" name="end_date" value={form.end_date || ""} onChange={handleChange}
              className="mt-1 w-full border border-gray-300 rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#7b1113]" />
          </div>
          <div className="col-span-2 flex items-center gap-2">
            <input type="checkbox" id="is_active" name="is_active" checked={form.is_active} onChange={handleChange}
              className="h-4 w-4 rounded border-gray-300 text-[#7b1113] focus:ring-[#7b1113]" />
            <label htmlFor="is_active" className="text-sm text-gray-700">
              Set as the active period (used as the default for new DH submissions)
            </label>
          </div>
        </div>

        <div className="flex gap-2 mt-4">
          <button onClick={handleSubmit} disabled={saving}
            className="bg-[#7b1113] text-white font-semibold py-2 px-6 rounded-lg hover:bg-[#5e0d0f] transition disabled:opacity-50">
            {saving ? "Saving..." : editId ? "Update Period" : "Add Period"}
          </button>
          {editId && (
            <button onClick={handleCancel}
              className="bg-gray-200 text-gray-700 font-semibold py-2 px-6 rounded-lg hover:bg-gray-300 transition">
              Cancel
            </button>
          )}
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <h3 className="text-base font-semibold text-gray-800 mb-4">All Academic Periods</h3>
        {loading ? <p className="text-gray-400 text-sm">Loading...</p>
        : periods.length === 0 ? <p className="text-gray-400 text-sm">No academic periods yet — add one above.</p>
        : (
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-4 text-gray-500 font-medium">School Year</th>
                <th className="text-left py-3 px-4 text-gray-500 font-medium">Semester</th>
                <th className="text-left py-3 px-4 text-gray-500 font-medium">Start</th>
                <th className="text-left py-3 px-4 text-gray-500 font-medium">End</th>
                <th className="text-left py-3 px-4 text-gray-500 font-medium">Status</th>
                <th className="text-left py-3 px-4 text-gray-500 font-medium">Action</th>
              </tr>
            </thead>
            <tbody>
              {periods.map((p) => (
                <tr key={p.id} className="border-b border-gray-50 hover:bg-gray-50">
                  <td className="py-3 px-4 font-semibold">{p.school_year}</td>
                  <td className="py-3 px-4">{p.semester}</td>
                  <td className="py-3 px-4">{p.start_date || "—"}</td>
                  <td className="py-3 px-4">{p.end_date || "—"}</td>
                  <td className="py-3 px-4">
                    {p.is_active ? (
                      <span className="px-2 py-1 rounded-full text-xs font-semibold bg-green-100 text-green-700">Active</span>
                    ) : (
                      <span className="px-2 py-1 rounded-full text-xs font-semibold bg-gray-100 text-gray-600">Inactive</span>
                    )}
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex gap-2">
                      {!p.is_active && (
                        <button onClick={() => handleSetActive(p)}
                          className="bg-green-500 text-white text-xs px-3 py-1 rounded-lg hover:bg-green-600 transition">
                          Set Active
                        </button>
                      )}
                      <button onClick={() => handleEdit(p)}
                        className="bg-blue-500 text-white text-xs px-3 py-1 rounded-lg hover:bg-blue-600 transition">
                        Edit
                      </button>
                      <button onClick={() => handleDelete(p.id)}
                        className="bg-red-500 text-white text-xs px-3 py-1 rounded-lg hover:bg-red-600 transition">
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
