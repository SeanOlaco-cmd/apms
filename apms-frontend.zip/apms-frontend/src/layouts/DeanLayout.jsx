import { Outlet, useNavigate } from "react-router-dom";
import NotificationBell from "../components/NotificationBell";
import AccountMenu from "../components/AccountMenu";

const navItems = [
  { label: "Dashboard", path: "/dean/dashboard" },
  { label: "Enrollment", path: "/dean/enrollment" },
  { label: "Retention", path: "/dean/retention" },
  { label: "Shiftee & Transferee", path: "/dean/shiftee-transferee" },
  { label: "Faculty Performance", path: "/dean/faculty-performance" },
  { label: "Achievements", path: "/dean/achievements" },
  { label: "Board Exam Results", path: "/dean/board-exam" },
  { label: "Student Performance", path: "/dean/student-performance" },
  { label: "Employees", path: "/dean/employees" },
];

export default function DeanLayout() {
  const navigate = useNavigate();
  const location = window.location.pathname;

  return (
    <div className="flex min-h-screen bg-gray-100">
      <div className="w-64 min-h-screen bg-[#7b1113] flex flex-col">
        <div className="p-6 border-b border-[#5e0d0f]">
          <h1 className="text-white font-bold text-xl">APMS</h1>
          <p className="text-red-200 text-xs mt-1">City College of Tagaytay</p>
        </div>
        <div className="p-4 border-b border-[#5e0d0f]">
          <p className="text-white font-semibold text-sm">Academic Performance</p>
          <p className="text-red-300 text-xs">Monitoring System</p>
        </div>
        <nav className="flex-1 p-3 flex flex-col gap-1 overflow-y-auto">
          {navItems.map((item) => (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className={`flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium transition w-full text-left
                ${location === item.path
                  ? "bg-white text-[#7b1113]"
                  : "text-red-100 hover:bg-[#5e0d0f]"
                }`}
            >
              {item.label}
            </button>
          ))}
        </nav>
      </div>

      <div className="flex-1 flex flex-col">
        <div className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-6">
          <h2 className="text-lg font-semibold text-gray-800">Dean Portal</h2>
          <div className="flex items-center gap-3">
            <NotificationBell />
            <AccountMenu />
          </div>
        </div>
        <main className="flex-1 p-6 overflow-y-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
}