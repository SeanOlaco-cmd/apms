import { useState, useEffect } from "react";
import api from "../../api/axios";

export default function DHStudentPerformance() {
  const user = JSON.parse(localStorage.getItem("user"));
  const [periods, setPeriods] = useState([]);
  const activePeriodId = periods.find((p) => p.is_active)?.id || "";
  const [submissions, setSubmissions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState("");
  const [error, setError] = useState("");
  const [editId, setEditId] = useState(null);

  const [form, setForm] = useState({
    academic_period_id: "",
    total_students: "",
    passing: "",
    failing: "",
    incomplete: "",
    dropped: "",
    passing_rate: "",
    average_gwa: "",
    latin_honors: "",
    notes: "",
  });

  useEffect(() => {
    api.get("/academic-periods").then((res) => {
      setPeriods(res.data);
      const active = res.data.find((p) => p.is_active);
      if (active) {
        setForm((f) => (f.academic_period_id ? f : { ...f, academic_period_id: active.id }));
      }
    });
    loadData();
  }, []);

  const loadData = async () => {
    const res = await api.get("/student-performance");
    const mine = res.data.filter(d => d.school_id == user.school_id && d.program_id == user.program_id);
    setSubmissions(mine);
  };

  const blockInvalidKeys = (e) => {
    if (["-", "+", "e", "E"].includes(e.key)) e.preventDefault();
  };

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleEdit = (row) => {
    setEditId(row.id);
    setForm({
      academic_period_id: row.academic_period_id,
      total_students: row.total_students,
      passing: row.passing,
      failing: row.failing,
      incomplete: row.incomplete,
      dropped: row.dropped,
      passing_rate: row.passing_rate,
      average_gwa: row.average_gwa,
      latin_honors: row.latin_honors,
      notes: row.notes ?? "",
    });
    window.scrollTo(0, 0);
  };

  const handleSubmit = async () => {
    setLoading(true);
    setError("");
    setSuccess("");
    try {
      if (editId) {
        await api.put(`/student-performance/${editId}`, { ...form, status: "pending" });
        setSuccess("Student performance data updated successfully!");
        setEditId(null);
      } else {
        await api.post("/student-performance", { ...form, school_id: user.school_id, program_id: user.program_id });
        setSuccess("Student performance data submitted!");
      }
      setForm({ academic_period_id: activePeriodId, total_students: "", passing: "", failing: "", incomplete: "", dropped: "", passing_rate: "", average_gwa: "", latin_honors: "", notes: "" });
      loadData();
    } catch (err) {
      const firstFieldError = err.response?.data?.errors && Object.values(err.response.data.errors)[0]?.[0];
      setError(firstFieldError || err.response?.data?.message || "Failed to submit. Please check all fields.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col gap-6">
      <div className="bg-[#7b1113] rounded-2xl p-6 text-white">
        <h1 className="text-2xl font-bold">Student Performance 🎓</h1>
        <p className="text-red-200 text-sm mt-1">Submit student performance data for your program.</p>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <h3 className="text-base font-semibold text-gray-800 mb-4">{editId ? "Edit Submission" : "New Submission"}</h3>
        {success && <div className="bg-green-50 text-green-700 text-sm px-4 py-2 rounded-lg mb-4">{success}</div>}
        {error && <div className="bg-red-50 text-red-700 text-sm px-4 py-2 rounded-lg mb-4">{error}</div>}
        <div className="grid grid-cols-2 gap-4">
          <div className="col-span-2">
            <label className="text-sm font-medium text-gray-700">Academic Period</label>
            <div className="mt-1 w-full border border-gray-200 bg-gray-50 rounded-lg px-4 py-2 text-sm text-gray-500">
              {(() => {
                const p = periods.find((pd) => pd.id == form.academic_period_id);
                return p ? `${p.school_year} - ${p.semester} Semester` : "Loading current period...";
              })()}
              <p className="text-xs text-gray-400 mt-1">Set automatically to the current academic period — cannot be changed here.</p>
            </div>
          </div>
          <div>
            <label className="text-sm font-medium text-gray-700">Total Students</label>
            <input type="number" name="total_students" value={form.total_students} onChange={handleChange} min="0" onKeyDown={blockInvalidKeys}
              className="mt-1 w-full border border-gray-300 rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#7b1113]" placeholder="0" />
          </div>
          <div>
            <label className="text-sm font-medium text-gray-700">Passing</label>
            <input type="number" name="passing" value={form.passing} onChange={handleChange} min="0" onKeyDown={blockInvalidKeys}
              className="mt-1 w-full border border-gray-300 rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#7b1113]" placeholder="0" />
          </div>
          <div>
            <label className="text-sm font-medium text-gray-700">Failing</label>
            <input type="number" name="failing" value={form.failing} onChange={handleChange} min="0" onKeyDown={blockInvalidKeys}
              className="mt-1 w-full border border-gray-300 rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#7b1113]" placeholder="0" />
          </div>
          <div>
            <label className="text-sm font-medium text-gray-700">Incomplete</label>
            <input type="number" name="incomplete" value={form.incomplete} onChange={handleChange} min="0" onKeyDown={blockInvalidKeys}
              className="mt-1 w-full border border-gray-300 rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#7b1113]" placeholder="0" />
          </div>
          <div>
            <label className="text-sm font-medium text-gray-700">Dropped</label>
            <input type="number" name="dropped" value={form.dropped} onChange={handleChange} min="0" onKeyDown={blockInvalidKeys}
              className="mt-1 w-full border border-gray-300 rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#7b1113]" placeholder="0" />
          </div>
          <div>
            <label className="text-sm font-medium text-gray-700">Passing Rate (%)</label>
            <input type="number" name="passing_rate" value={form.passing_rate} onChange={handleChange} min="0" onKeyDown={blockInvalidKeys}
              className="mt-1 w-full border border-gray-300 rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#7b1113]" placeholder="0.00" step="0.01" />
          </div>
          <div>
            <label className="text-sm font-medium text-gray-700">Average GWA</label>
            <input type="number" name="average_gwa" value={form.average_gwa} onChange={handleChange} min="0" onKeyDown={blockInvalidKeys}
              className="mt-1 w-full border border-gray-300 rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#7b1113]" placeholder="0.00" step="0.01" />
          </div>
          <div>
            <label className="text-sm font-medium text-gray-700">Latin Honors</label>
            <input type="number" name="latin_honors" value={form.latin_honors} onChange={handleChange} min="0" onKeyDown={blockInvalidKeys}
              className="mt-1 w-full border border-gray-300 rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#7b1113]" placeholder="0" />
          </div>
          <div className="col-span-2">
            <label className="text-sm font-medium text-gray-700">Notes (optional)</label>
            <textarea name="notes" value={form.notes} onChange={handleChange}
              className="mt-1 w-full border border-gray-300 rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#7b1113]"
              rows={3} placeholder="Add any notes here..." />
          </div>
        </div>
        <div className="flex gap-2 mt-4">
          <button onClick={handleSubmit} disabled={loading}
            className="bg-[#7b1113] text-white font-semibold py-2 px-6 rounded-lg hover:bg-[#5e0d0f] transition disabled:opacity-50">
            {loading ? "Saving..." : editId ? "Update Submission" : "Submit"}
          </button>
          {editId && (
            <button onClick={() => { setEditId(null); setForm({ academic_period_id: activePeriodId, total_students: "", passing: "", failing: "", incomplete: "", dropped: "", passing_rate: "", average_gwa: "", latin_honors: "", notes: "" }); }}
              className="bg-gray-200 text-gray-700 font-semibold py-2 px-6 rounded-lg hover:bg-gray-300 transition">
              Cancel
            </button>
          )}
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <h3 className="text-base font-semibold text-gray-800 mb-4">My Submissions</h3>
        {submissions.length === 0 ? <p className="text-gray-400 text-sm">No submissions yet.</p> : (
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-4 text-gray-500 font-medium">Period</th>
                <th className="text-left py-3 px-4 text-gray-500 font-medium">Total</th>
                <th className="text-left py-3 px-4 text-gray-500 font-medium">Passing</th>
                <th className="text-left py-3 px-4 text-gray-500 font-medium">Failing</th>
                <th className="text-left py-3 px-4 text-gray-500 font-medium">Passing Rate</th>
                <th className="text-left py-3 px-4 text-gray-500 font-medium">Status</th>
                <th className="text-left py-3 px-4 text-gray-500 font-medium">Action</th>
              </tr>
            </thead>
            <tbody>
              {submissions.map((row) => (
                <tr key={row.id} className="border-b border-gray-50 hover:bg-gray-50">
                  <td className="py-3 px-4">{row.academic_period?.school_year} - {row.academic_period?.semester}</td>
                  <td className="py-3 px-4">{row.total_students}</td>
                  <td className="py-3 px-4 text-green-600">{row.passing}</td>
                  <td className="py-3 px-4 text-red-500">{row.failing}</td>
                  <td className="py-3 px-4 font-semibold">{row.passing_rate}%</td>
                  <td className="py-3 px-4">
                    <span className={`px-2 py-1 rounded-full text-xs font-semibold capitalize
                      ${row.status === 'approved' ? 'bg-green-100 text-green-700' :
                        row.status === 'dean_approved' ? 'bg-blue-100 text-blue-700' :
                        row.status === 'rejected' ? 'bg-red-100 text-red-700' :
                        'bg-yellow-100 text-yellow-700'}`}>
                      {row.status === 'dean_approved' ? 'Awaiting VPAA' : row.status}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    {(row.status === 'rejected') && (
                      <button onClick={() => handleEdit(row)}
                        className="bg-blue-500 text-white text-xs px-3 py-1 rounded-lg hover:bg-blue-600 transition">
                        Edit
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}