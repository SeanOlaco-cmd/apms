import { useState } from "react";
import api from "../api/axios";
import { useNavigate, useLocation } from "react-router-dom";

export default function Login() {
  const [login, setLogin] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  // Set when you were signed out automatically (e.g. after being inactive).
  const notice = useLocation().state?.message;

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const res = await api.post("/login", { login, password });
      localStorage.setItem("token", res.data.token);
      localStorage.setItem("user", JSON.stringify(res.data.user));

      const role = res.data.user.role;
      if (role === "president") {
        navigate("/dashboard");
      } else if (role === "dean") {
        navigate("/dean/dashboard");
      } else if (role === "vpaa") {
        navigate("/vpaa/dashboard");
      } else if (role === "system_admin") {
        navigate("/admin/dashboard");
      } else if (role === "department_head") {
        navigate("/dh/dashboard");
      }
    } catch (err) {
      setError(err.response?.data?.message || "Invalid email/username or password.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#7b1113] flex items-center justify-center">
      <div className="bg-white rounded-2xl shadow-2xl p-10 w-full max-w-md animate-fade-up">
        <div className="text-center mb-8">
          <h1 className="text-xl font-bold text-[#7b1113]">Academic Performance Monitoring System</h1>
            <p className="text-gray-500 text-sm mt-1">
             City College of Tagaytay
            </p>
        </div>

        {notice && !error && (
          <div className="bg-blue-50 text-blue-700 text-sm px-4 py-2 rounded-lg mb-4">
            {notice}
          </div>
        )}

        {error && (
          <div className="bg-red-100 text-red-700 text-sm px-4 py-2 rounded-lg mb-4">
            {error}
          </div>
        )}

        <form onSubmit={handleLogin} className="flex flex-col gap-4">
          <div>
            <label className="text-sm font-medium text-gray-700">
              Email or Username
            </label>
            <input
              type="text"
              value={login}
              onChange={(e) => setLogin(e.target.value)}
              className="mt-1 w-full border border-gray-300 rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#7b1113]"
              placeholder="you@cct.edu.ph or username"
              required
            />
          </div>
          <div>
            <label className="text-sm font-medium text-gray-700">
              Password
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="mt-1 w-full border border-gray-300 rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#7b1113]"
              placeholder="••••••••"
              required
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="bg-[#7b1113] text-white font-semibold py-2 rounded-lg hover:bg-[#5e0d0f] transition disabled:opacity-50"
          >
            {loading ? "Logging in..." : "Login"}
          </button>
        </form>
      </div>
    </div>
  );
}