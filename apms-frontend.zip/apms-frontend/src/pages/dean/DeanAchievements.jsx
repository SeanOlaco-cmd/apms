import DeanReviewPage from "../../components/DeanReviewPage";
import { recipientLabel, yearSection } from "../../lib/achievements";

const columns = [
  { label: "Recipient", render: (r) => r.faculty_name },
  { label: "Category", render: (r) => recipientLabel(r) },
  { label: "Year & Section", render: (r) => yearSection(r) || "—" },
  { label: "Achievement", render: (r) => r.achievement_title },
  { label: "Type", render: (r) => r.type, className: "capitalize" },
  { label: "Date", render: (r) => r.date_awarded ?? "—" },
];

export default function DeanAchievements() {
  return (
    <DeanReviewPage
      title="Achievement Submissions 🏆"
      subtitle="Review and approve faculty and student achievements."
      uri="/achievements"
      columns={columns}
      byProgram={false}
    />
  );
}