import VPAAReviewPage from "../../components/VPAAReviewPage";
import { recipientLabel, yearSection } from "../../lib/achievements";

const columns = [
  { label: "Recipient", render: (r) => r.faculty_name },
  { label: "Category", render: (r) => recipientLabel(r) },
  { label: "Year & Section", render: (r) => yearSection(r) || "—" },
  { label: "Achievement", render: (r) => r.achievement_title },
  { label: "Type", render: (r) => r.type, className: "capitalize" },
  { label: "Date", render: (r) => r.date_awarded ?? "—" },
];

export default function VPAAAchievements() {
  return (
    <VPAAReviewPage
      title="Achievements 🏆"
      subtitle="Review faculty and student achievements approved by each school's Dean."
      uri="/achievements"
      columns={columns}
    />
  );
}