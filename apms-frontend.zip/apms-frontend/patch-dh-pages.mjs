// One-time helper. Run from the apms-frontend folder:   node patch-dh-pages.mjs
// Safe to run twice (it skips anything already fixed). Delete this file afterwards.
//
// What it does to src/pages/dh/DH*.jsx:
//   1) Number inputs: add min="0" and block the - + e E keys (same behaviour the
//      Shiftee and Retention pages already have), only where missing.
//   2) Submit errors: show the real validation message instead of a generic one.
//   3) Status badge: a Dean-approved record reads "Awaiting VPAA", not "dean_approved".
import fs from "fs";
import path from "path";

const dir = path.join("src", "pages", "dh");
if (!fs.existsSync(dir)) {
  console.error("Run this from the apms-frontend folder (src/pages/dh not found).");
  process.exit(1);
}

const HELPER =
  `const blockInvalidKeys = (e) => {\n` +
  `    if (["-", "+", "e", "E"].includes(e.key)) e.preventDefault();\n` +
  `  };\n\n  `;

let touched = 0;
for (const file of fs.readdirSync(dir).filter((f) => /^DH.*\.jsx$/.test(f))) {
  const p = path.join(dir, file);
  const raw = fs.readFileSync(p, "utf8");
  const eol = raw.includes("\r\n") ? "\r\n" : "\n";
  let s = raw.replace(/\r\n/g, "\n");
  const done = [];
  let needsHelper = false;

  // 1) numeric inputs — look at the WHOLE tag so we never create duplicate props.
  s = s.replace(/<input type="number"[\s\S]*?\/>/g, (tag) => {
    let add = "";
    if (!/\smin=/.test(tag)) { add += ' min="0"'; done.push('min="0"'); }
    if (!/onKeyDown=/.test(tag)) { add += " onKeyDown={blockInvalidKeys}"; needsHelper = true; done.push("key blocker"); }
    if (!add || !/onChange=\{handleChange\}/.test(tag)) return tag;
    return tag.replace(/(onChange=\{handleChange\})/, `$1${add}`);
  });
  if (needsHelper && !/const blockInvalidKeys/.test(s)) {
    s = s.replace(/(\n {2})(const handleChange\b)/, `$1${HELPER}$2`);
    done.push("blockInvalidKeys helper");
  }

  // 2) real validation message
  s = s.replace(
    /\} catch \{\n(\s*)setError\("Failed to submit\. Please check all fields\."\);/g,
    (m, ind) => {
      done.push("real error message");
      return (
        `} catch (err) {\n` +
        `${ind}const firstFieldError = err.response?.data?.errors && Object.values(err.response.data.errors)[0]?.[0];\n` +
        `${ind}setError(firstFieldError || err.response?.data?.message || "Failed to submit. Please check all fields.");`
      );
    }
  );

  // 3) status badge
  s = s.replace(
    /row\.status === 'rejected' \? 'bg-red-100 text-red-700' :\n(\s*)'bg-yellow-100 text-yellow-700'\}`\}>\n(\s*)\{row\.status\}/g,
    (m, i1, i2) => {
      done.push("Awaiting VPAA badge");
      return (
        `row.status === 'dean_approved' ? 'bg-blue-100 text-blue-700' :\n` +
        `${i1}row.status === 'rejected' ? 'bg-red-100 text-red-700' :\n` +
        `${i1}'bg-yellow-100 text-yellow-700'}\`}>\n` +
        `${i2}{row.status === 'dean_approved' ? 'Awaiting VPAA' : row.status}`
      );
    }
  );

  if (done.length) {
    fs.writeFileSync(p, s.replace(/\n/g, eol));
    touched++;
    const counts = done.reduce((a, k) => ((a[k] = (a[k] || 0) + 1), a), {});
    console.log(`patched ${file}: ` + Object.entries(counts).map(([k, v]) => (v > 1 ? `${k} x${v}` : k)).join(", "));
  } else {
    console.log(`ok      ${file}: nothing to change`);
  }
}
console.log(`\nDone. ${touched} file(s) changed.`);