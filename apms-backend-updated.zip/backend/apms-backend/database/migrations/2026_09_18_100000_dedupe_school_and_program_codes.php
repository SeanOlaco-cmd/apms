<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * SchoolSeeder and ProgramSeeder just do a raw insert with no check for
 * existing rows, and schools.code / programs.code have never had a
 * unique constraint. If `php artisan db:seed` (not migrate:fresh --seed)
 * is ever run a second time on a database that already has schools and
 * programs in it — which is easy to do by accident when iterating on a
 * live Railway deploy — you silently end up with two rows sharing the
 * same code (e.g. two "SCS" schools with different ids).
 *
 * That's exactly what causes a Dean to get "Not your school" trying to
 * approve a DH submission that's clearly from their own school on
 * screen: their user row and the submission row ended up pointing at
 * two *different* rows that both display as "SCS".
 *
 * This migration is safe to run whether or not duplicates currently
 * exist. If there are none, dedupeByCode() is a no-op and only the
 * unique constraints get added.
 */
return new class extends Migration
{
    /**
     * @var array<string,string> table => the foreign key column on it
     *      that points at schools.id
     */
    protected array $schoolRefs = [
        'users' => 'school_id',
        'programs' => 'school_id',
        'enrollment_data' => 'school_id',
        'retention_rates' => 'school_id',
        'shiftee_transferee_data' => 'school_id',
        'faculty_performance' => 'school_id',
        'faculty_achievements' => 'school_id',
        'board_exam_results' => 'school_id',
        'student_performance' => 'school_id',
        'employee_data' => 'school_id',
        'class_monitoring' => 'school_id',
    ];

    /** @var array<string,string> table => column pointing at programs.id */
    protected array $programRefs = [
        'users' => 'program_id',
        'enrollment_data' => 'program_id',
        'retention_rates' => 'program_id',
        'shiftee_transferee_data' => 'program_id',
        'board_exam_results' => 'program_id',
        'student_performance' => 'program_id',
        'employee_data' => 'program_id',
        'class_monitoring' => 'program_id',
    ];

    public function up(): void
    {
        $this->dedupeByCode('schools', $this->schoolRefs);
        $this->dedupeByCode('programs', $this->programRefs);

        $this->addUniqueIfMissing('schools', 'code');
        $this->addUniqueIfMissing('programs', 'code');
    }

    public function down(): void
    {
        // Merged/deleted rows can't be un-merged, and dropping the
        // unique constraints is harmless — nothing to redo here.
        Schema::table('schools', function (Blueprint $table) {
            $table->dropUnique(['code']);
        });
        Schema::table('programs', function (Blueprint $table) {
            $table->dropUnique(['code']);
        });
    }

    /**
     * For every group of rows in $table sharing the same "code", keep the
     * lowest id (the original, canonical row) and re-point every foreign
     * key in $refs from the duplicate ids onto the canonical id, then
     * delete the now-unreferenced duplicate rows.
     */
    protected function dedupeByCode(string $table, array $refs): void
    {
        if (! Schema::hasTable($table) || ! Schema::hasColumn($table, 'code')) {
            return;
        }

        $groups = DB::table($table)
            ->select('code')
            ->groupBy('code')
            ->havingRaw('COUNT(*) > 1')
            ->pluck('code');

        foreach ($groups as $code) {
            $rows = DB::table($table)->where('code', $code)->orderBy('id')->pluck('id');
            $canonical = $rows->first();
            $duplicates = $rows->slice(1)->values();

            if ($duplicates->isEmpty()) {
                continue;
            }

            foreach ($refs as $refTable => $column) {
                if (! Schema::hasTable($refTable) || ! Schema::hasColumn($refTable, $column)) {
                    continue;
                }

                DB::table($refTable)
                    ->whereIn($column, $duplicates)
                    ->update([$column => $canonical]);
            }

            DB::table($table)->whereIn('id', $duplicates)->delete();
        }
    }

    protected function addUniqueIfMissing(string $table, string $column): void
    {
        if (! Schema::hasTable($table)) {
            return;
        }

        try {
            Schema::table($table, function (Blueprint $blueprint) use ($column) {
                $blueprint->unique($column);
            });
        } catch (\Throwable $e) {
            // Constraint already exists, or (unexpectedly) duplicates
            // remain — don't fail the whole deploy over it.
        }
    }
};
