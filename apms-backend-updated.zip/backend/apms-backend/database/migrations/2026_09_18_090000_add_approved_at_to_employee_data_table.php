<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * employee_data was created without an approved_at column, unlike every
 * other approval-workflow table (enrollment_data, retention_rates, etc).
 * EmployeeController@review always writes approved_at, so approving or
 * rejecting an Employees submission throws a "column not found" SQL
 * error. This adds the missing column to bring the table in line with
 * the rest of the approval-workflow tables.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('employee_data', function (Blueprint $table) {
            if (! Schema::hasColumn('employee_data', 'approved_at')) {
                $table->timestamp('approved_at')->nullable()->after('approved_by');
            }
        });
    }

    public function down(): void
    {
        Schema::table('employee_data', function (Blueprint $table) {
            $table->dropColumn('approved_at');
        });
    }
};
