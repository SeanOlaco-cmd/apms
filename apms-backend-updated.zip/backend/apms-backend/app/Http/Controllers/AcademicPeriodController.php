<?php

namespace App\Http\Controllers;

use App\Models\AcademicPeriod;
use Illuminate\Http\Request;

class AcademicPeriodController extends Controller
{
    public function index()
    {
        return AcademicPeriod::all();
    }

    public function store(Request $request)
    {
        $request->validate([
            'school_year' => 'required|string',
            'semester' => 'required|in:1st,2nd,Summer',
            'start_date' => 'nullable|date',
            'end_date' => 'nullable|date',
            'is_active' => 'boolean',
        ]);

        if ($request->boolean('is_active')) {
            AcademicPeriod::where('is_active', true)->update(['is_active' => false]);
        }

        $period = AcademicPeriod::create($request->all());
        return response()->json($period, 201);
    }

    public function show(AcademicPeriod $academicPeriod)
    {
        return $academicPeriod;
    }

    public function update(Request $request, AcademicPeriod $academicPeriod)
    {
        $request->validate([
            'school_year' => 'sometimes|string',
            'semester' => 'sometimes|in:1st,2nd,Summer',
            'start_date' => 'nullable|date',
            'end_date' => 'nullable|date',
            'is_active' => 'boolean',
        ]);

        // Only one academic period should be "active" at a time — it's
        // used as the default period on DH submission forms.
        if ($request->boolean('is_active')) {
            AcademicPeriod::where('is_active', true)
                ->where('id', '!=', $academicPeriod->id)
                ->update(['is_active' => false]);
        }

        $academicPeriod->update($request->all());
        return response()->json($academicPeriod);
    }

    public function destroy(AcademicPeriod $academicPeriod)
    {
        $academicPeriod->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }
}